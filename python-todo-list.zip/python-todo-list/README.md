# Python To-Do List Manager

A beginner-friendly command-line task manager built with Python. Tasks are saved locally in a JSON file, so they remain available after the program closes.

## Features

- Add new tasks
- View all tasks
- Mark tasks as complete
- Delete tasks
- Automatically save tasks in `tasks.json`
- Uses only Python's standard library (no extra packages required)

## Requirements

- Python 3.8 or newer

## How to Run

1. Download or clone this repository.
2. Open a terminal in the project folder.
3. Run:

   ```bash
   python main.py
   ```

   On some systems, use `python3 main.py` instead.

## Example

```text
=== Python To-Do List Manager ===
1. View tasks
2. Add a task
3. Mark task complete
4. Delete a task
5. Exit
Choose an option (1-5): 2
Enter a task: Learn GitHub
Task added successfully!
```

## Project Structure

```text
python-todo-list/
├── main.py
├── README.md
└── tasks.json  # created automatically when you save your first task
```

## What I Learned

- Python functions and loops
- Lists and dictionaries
- Reading and writing JSON files
- Handling invalid user input
- Organizing a small Python project

## License

This project is available under the MIT License.
