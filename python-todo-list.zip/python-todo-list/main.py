import json
from pathlib import Path

DATA_FILE = Path(__file__).with_name("tasks.json")


def load_tasks():
    """Load saved tasks, or return an empty list if no data exists yet."""
    if not DATA_FILE.exists():
        return []
    try:
        with DATA_FILE.open("r", encoding="utf-8") as file:
            data = json.load(file)
        return data if isinstance(data, list) else []
    except (json.JSONDecodeError, OSError):
        print("Warning: Could not read tasks.json. Starting with an empty list.")
        return []


def save_tasks(tasks):
    """Save tasks to a JSON file."""
    with DATA_FILE.open("w", encoding="utf-8") as file:
        json.dump(tasks, file, indent=2, ensure_ascii=False)


def show_tasks(tasks):
    if not tasks:
        print("\nYour task list is empty.")
        return

    print("\n--- Your Tasks ---")
    for number, task in enumerate(tasks, start=1):
        status = "✓" if task["completed"] else " "
        print(f'{number}. [{status}] {task["title"]}')


def add_task(tasks):
    title = input("Enter a task: ").strip()
    if not title:
        print("Task cannot be empty.")
        return
    tasks.append({"title": title, "completed": False})
    save_tasks(tasks)
    print("Task added successfully!")


def complete_task(tasks):
    show_tasks(tasks)
    if not tasks:
        return
    try:
        number = int(input("Enter task number to mark complete: "))
        if not 1 <= number <= len(tasks):
            raise ValueError
    except ValueError:
        print("Please enter a valid task number.")
        return

    tasks[number - 1]["completed"] = True
    save_tasks(tasks)
    print("Task marked as complete!")


def delete_task(tasks):
    show_tasks(tasks)
    if not tasks:
        return
    try:
        number = int(input("Enter task number to delete: "))
        if not 1 <= number <= len(tasks):
            raise ValueError
    except ValueError:
        print("Please enter a valid task number.")
        return

    removed = tasks.pop(number - 1)
    save_tasks(tasks)
    print(f'Task deleted: {removed["title"]}')


def main():
    tasks = load_tasks()
    while True:
        print("\n=== Python To-Do List Manager ===")
        print("1. View tasks")
        print("2. Add a task")
        print("3. Mark task complete")
        print("4. Delete a task")
        print("5. Exit")
        choice = input("Choose an option (1-5): ").strip()

        if choice == "1":
            show_tasks(tasks)
        elif choice == "2":
            add_task(tasks)
        elif choice == "3":
            complete_task(tasks)
        elif choice == "4":
            delete_task(tasks)
        elif choice == "5":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please choose a number from 1 to 5.")


if __name__ == "__main__":
    main()
